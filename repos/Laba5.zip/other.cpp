#include "other.h"

///////////////////////////////////////////////////
#define _CRT_SECURE_NO_WARNINGS
#include <cstdio>
#include <stdlib.h>
#include <string.h>
#define	  stop __asm nop


void Sort(char* pcFirst, int nNumber, int size,
	 void (*Swap)(void*, void*), int (*Compare)(void*, void*) )
{
	int i;
	for(i=1; i<nNumber; i++)
		for(int j=nNumber-1; j>=i; j--)
		{
			char* pCurrent = pcFirst+j*size;
			char* pPrevious = pcFirst+(j-1)*size;
			if((*Compare)( pPrevious, pCurrent ) > 0)
				(*Swap)( pPrevious, pCurrent );
		}
}

void SwapInt(void* p1, void* p2)
{	
	*(int *)p1 ^= *(int *)p2;
	*(int *)p2 ^= *(int *)p1;
	*(int *)p1 ^= *(int *)p2;
}


int CmpInt(void* p1, void* p2)
{
	int nResult;

	if (*(int *)p1 > *(int *)p2)
		nResult = 1;
	else if (*(int *)p1 == *(int *)p2)
		nResult = 0;
	else
		nResult = -1;

	return nResult;
}


double Sum(double sum1, double sum2)
{
	return sum1 + sum2;
}

double Sub(double sub1, double sub2)
{
	return sub1 - sub2;
}

double Mul(double mul1, double mul2)
{
	return mul1 * mul2;
}

double Div(double div1, double div2)
{
	return div1 / div2;
}

void SwapDouble(void* p1, void* p2)
{
	double tmp = *(double *)p1;
	*(double *)p1 = *(double *)p2;
	*(double *)p2 = tmp;
}

int CmpDouble(void* p1, void* p2)
{
	int nResult;

	if (*(double *)p1 > *(double *)p2)
		nResult = 1;
	else if (*(double *)p1 == *(double *)p2)
		nResult = 0;
	else
		nResult = -1;

	return nResult;
}

void SwapStr(void* p1, void* p2)
{
	char* tmp = *(char **)p1;
	*(char **)p1 = *(char **)p2;
	*(char **)p2 = tmp;
}

int CmpStr(void* p1, void* p2)
{
	return strcmp(*(char **)p1, *(char **)p2);
}


int readLine(char **pStr) {

	char buf[256];
	int len;
	printf("Input string: ");
	fgets(buf, sizeof(buf), stdin);
	len = strlen(buf);

	if (buf[len - 1] == '\n')
		buf[len - 1] = 0;

	*pStr = (char *)calloc(len, sizeof(char));
	strcpy(*pStr, buf);

	return len;

}



int readLines(char ***pStrings) {

	int n, i;
	printf("How many strings to input: ");
	scanf("%d", &n);
	getc(stdin);
	*pStrings = (char **)calloc(n, sizeof(char *));

	for (i = 0; i < n; i++)
		readLine(&(*pStrings)[i]);

	return n;

}

const char* GetString1()
{
	return "AA";
}

const char* GetString2()
{
	return "BB";
}

const char* GetString3()
{
	return "CC";
}

const char* GetString4()
{
	return "DD";
}

void PrintStructFields(BOOK &st)
{
	printf("Author: %s \nTitle: %s \nYear: %i \nPrice: %i \nCategory: %s \n", st.author, st.title, st.year, st.price, st.category);
}

void FieldsFormation(BOOK &st)
{
	scanf("%s%s%i%i%s", (st.author), (st.title), (st.year), (st.price), (st.category));
}