
//��������� ������������ � ������ ������� �������:

void Sort(char* pcFirst, int nNumber, int size,
	 void (*Swap)(void*, void*), int (*Compare)(void*, void*) );
void SwapInt(void* p1, void* p2);
int CmpInt(void* p1, void* p2);

double Sum(double sum1, double sum2);
double Sub(double sub1, double sub2);
double Mul(double mul1, double mul2); 
double Div(double div1, double div2);

void SwapDouble(void* p1, void* p2);
int CmpDouble(void* p1, void* p2);

void SwapStr(void* p1, void* p2);
int CmpStr(void* p1, void* p2);
int readLine(char **pStr);
int readLines(char ***pStrings);

const char* GetString1();
const char* GetString2();
const char* GetString3();
const char* GetString4();

struct BOOK
{
	char* author;
	char* title;
	int year;
	int price;
	char* category;
};

void PrintStructFields(BOOK &st);

void FieldsFormation(BOOK &st);